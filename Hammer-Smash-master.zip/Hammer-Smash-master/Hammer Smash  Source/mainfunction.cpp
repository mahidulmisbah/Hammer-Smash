#include "graphics.h"
#include<bits/stdc++.h>
#include<string.h>
#include"1.game_window.h"

int main()
{
    int quit=startmenu();
    return 0;
}

//Total lines of code 1074.


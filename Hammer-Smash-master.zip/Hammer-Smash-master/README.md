# Hammer-Smash
add bgi library to your system
and just run the source code
for any query mail me at inzamam.csedu@gmail.com
<a href="https://www.youtube.com/watch?v=uMkD15txLeo" target="_blank"><img src="http://img.youtube.com/vi/uMkD15txLeo/0.jpg" 
alt="IMAGE ALT TEXT HERE" width="240" height="180" border="10" /></a>
